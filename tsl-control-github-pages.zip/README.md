# TSL Control App

App PWA para controle de revisão de máquinas baseado em horímetro.
