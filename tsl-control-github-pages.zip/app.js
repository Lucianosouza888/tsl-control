
document.getElementById('root').innerHTML = '<h2 style="text-align:center;margin-top:2rem;">TSL Control PWA</h2><p style="text-align:center;">App instalado com sucesso!</p>';
